package sorters;

public interface SorterGenerator {
    SorterGenerator ShellSort();
    SorterGenerator insertionSort();
    SorterGenerator brushSort();
}
